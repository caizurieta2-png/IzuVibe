# IzuVibe para iOS

Adaptación de Trop v0.0.4 con identidad celeste y negra.

**Estado: código preparado; compilación y prueba en iPhone pendientes.**

Lee [la guía de IzuVibe](IZUVIBE_LEEME.md) para compilar e instalar.

Base original: [SwiftyMedia/Trop](https://github.com/SwiftyMedia/Trop). Licencia original GPL v3 y créditos conservados.

---

## Documentación del proyecto original

# Trop

A free and open source YouTube Music client for iOS.

<p>
	<img src=".github/assets/1.png" width="25%" alt="Homepage" />
	<img src=".github/assets/2.png" width="25%" alt="Player" />
	<img src=".github/assets/3.png" width="25%" alt="Queue" />
</p>

## Features

- No ads
- SponsorBlock: skips sponsor reads, intros, outros and non-music sections (silence, talking)
- Stream songs and videos from YouTube Music
- Synced lyrics (Musixmatch, Netease, Kugou, LRCLIB, Genius)
- Library sync (playlists, albums, artists, podcasts)
- Downloads
- Equalizer
- Custom app icons and themes
- Queue management and listening history

## Installation

Requires iOS 26 or later and a YouTube Music account (sign in through the in-app web view).

### Feather / AltStore / SideStore

Add the Trop source, then install the latest stable release (unsigned - your client re-signs it with your Apple ID):

```
https://raw.githubusercontent.com/SwiftyMedia/Trop/main/altstore.json
```


> **Note:** AltStore PAL is not supported.

Stable releases are available from the [releases page](../../releases). Nightly builds are available in the[Actions](../../actions) tab.

### Manual Installation

 To build an unsigned IPA locally, run `./build_ipa.sh`; the output is `build/Trop.ipa`.

## Notable mentions

- [InnerTubeX](https://github.com/MetrolistGroup/innertubex) - eXtended InnerTube API library for Kotlin
- [zemer-cipher](https://github.com/ZemerTeam/zemer-cipher) - YouTube cipher deobfuscation and PoToken generation
- [Metrolist](https://github.com/MetrolistGroup/Metrolist) - YouTube Music client for Android

## Community

Join the [Discord server](https://discord.gg/QrMwZAfU97) for support and discussion.

## License

This repo is licensed under [GPLv3](LICENSE.txt). Trop is not affiliated with, endorsed, or sponsored by Google or YouTube.
