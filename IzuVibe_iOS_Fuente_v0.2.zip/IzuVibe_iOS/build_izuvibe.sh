#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

if [ "$(uname -s)" != "Darwin" ]; then
  echo "La compilación iOS necesita macOS y Xcode. Ejecuta el workflow manual de GitHub desde Windows."
  exit 1
fi
command -v xcodebuild >/dev/null || { echo "Falta Xcode."; exit 1; }
# Preserve the upstream target/scheme and proven FFmpeg/MPV packaging logic.
bash ./build_ipa.sh
test -f build/Trop.ipa
cp build/Trop.ipa build/IzuVibe.ipa
shasum -a 256 build/IzuVibe.ipa > build/IzuVibe.ipa.sha256
echo "IPA sin firmar: build/IzuVibe.ipa. Aún requiere firma para instalar en iPhone."
