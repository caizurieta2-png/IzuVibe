# IzuVibe personal DJ: source and verification

Grounding and closed-candidate projection principles are adapted from SUB/WAVE
v1.31.0, commit 5cfabe5b7fe6f0c9b08d562509f0adedd6213e85:

- controller/src/broadcast/dj-agent/shortlist-pick.ts, lines 141-177 and 211-256:
  project only permitted metadata; identities must belong to supplied candidates;
  absent musical measurements are unknown. This port never reorders the queue.
- controller/src/llm/internal/prompts/grounding.ts, lines 16-23:
  style does not authorize invented location or other facts. Location, weather,
  biographies, genre and measured sound properties are omitted in this port.

Source: https://github.com/perminder-klair/subwave/tree/v1.31.0

The Swift modules are a new adaptation, without SUB/WAVE runtime dependencies.
The model chooses a closed presentation template and whether to mention the
actual next queued song; Swift adds the verified title/artist. Thus the model
cannot add a fabricated music fact to spoken text. Basic fallback uses the same
verified rendering. This is narrower than SUB/WAVE's open-ended DJ speech.

The friendly version has twelve presentations per language and six gentle music
jokes. Optional humor defaults on, occurs every third presentation, and can be
demonstrated by the first manual Speak now. It never jokes about the listener.
An optional objective artist observation requires three distinct track IDs with
at least 30 seconds each of observed playback advances in this app session.
The small in-memory observer skips paused playback and large position jumps;
missed background ticks are ignored conservatively. It infers no genre, mood,
personal taste or emotion and saves no listening history to disk.

Apple Foundation Models and AVSpeechSynthesizer provide the local mobile
implementation. Kokoro is not bundled and its PC demo voice is not promised on
iPhone. No API keys, stream URLs, account data or lyrics enter the model prompt.
Among voices the system reports available, Spanish prefers es-MX (then es-US),
with premium/enhanced quality preferred within a locale. No voice is downloaded
by this code; quality and accent depend on the device's installed voices. The
slightly slower rate and small pauses do not promise Siri-like expressiveness.

DJ is opt-in, off by default. Cancellation invalidates pending generation and
restores the transient mpv volume multiplier. Music volume preferences are never
overwritten. `audio-exclusive` is disabled only while DJ is enabled (startup
setting and best-effort live option). This must be checked on physical iPhone:
playback continuity, voice/music mix, Bluetooth, interruptions, lock screen,
rapid skips, disabling DJ, and manual volume edits while DJ is speaking.

Prepared on Windows; Xcode compilation and physical-device audio are not yet
verified. Target APIs are iOS 26.x (no iOS 27 error/session APIs).

## Original MIT license retained

MIT License

Copyright (c) 2026 Parminder Klair

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
