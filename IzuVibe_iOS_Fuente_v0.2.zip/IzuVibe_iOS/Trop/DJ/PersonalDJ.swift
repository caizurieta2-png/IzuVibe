import AVFoundation
import Combine
import Foundation
import Observation

@Observable
@MainActor
final class PersonalDJ: NSObject {
    static let shared = PersonalDJ()

    var isEnabled: Bool {
        didSet {
            UserDefaults.standard.set(isEnabled, forKey: DJPreferences.enabledKey)
            if !isEnabled {
                stop()
                listeningTask?.cancel()
                listeningTask = nil
            } else if let trackID = NowPlaying.shared.videoId {
                startListeningObservation(trackID: trackID)
            }
            PlayerController.shared.applyDJAudioMixing(enabled: isEnabled)
        }
    }
    var frequency: Int {
        didSet { UserDefaults.standard.set(frequency, forKey: DJPreferences.frequencyKey) }
    }
    var language: DJLanguage {
        didSet {
            UserDefaults.standard.set(language.rawValue, forKey: DJPreferences.languageKey)
            stop()
        }
    }
    var humorEnabled: Bool {
        didSet { UserDefaults.standard.set(humorEnabled, forKey: DJPreferences.humorKey) }
    }
    private(set) var isPreparing = false
    private(set) var isSpeaking = false
    private(set) var lastSpeech = ""
    private(set) var lastUsedAI = false

    @ObservationIgnored private let synthesizer = AVSpeechSynthesizer()
    @ObservationIgnored private var generationTask: Task<Void, Never>?
    @ObservationIgnored private var planningTimeout: Task<Void, Never>?
    @ObservationIgnored private var speechTimeout: Task<Void, Never>?
    @ObservationIgnored private var requestID = UUID()
    @ObservationIgnored private var currentTrackID: String?
    @ObservationIgnored private var tracksSinceSpeech = 0
    @ObservationIgnored private var sequence = 0
    @ObservationIgnored private var activeUtterance: AVSpeechUtterance?
    @ObservationIgnored private var previousTemplate: Int?
    @ObservationIgnored private var listeningTask: Task<Void, Never>?
    @ObservationIgnored private var listeningSeconds: [String: TimeInterval] = [:]
    @ObservationIgnored private var qualifiedTrackIDs = Set<String>()
    @ObservationIgnored private var artistTrackIDs: [String: Set<String>] = [:]

    private override init() {
        isEnabled = DJPreferences.isEnabled
        let storedFrequency = UserDefaults.standard.integer(forKey: DJPreferences.frequencyKey)
        frequency = (1...6).contains(storedFrequency) ? storedFrequency : 3
        language = DJLanguage(rawValue: UserDefaults.standard.string(forKey: DJPreferences.languageKey) ?? "system") ?? .system
        humorEnabled = UserDefaults.standard.object(forKey: DJPreferences.humorKey) as? Bool ?? true
        super.init()
        synthesizer.usesApplicationAudioSession = true
        synthesizer.delegate = self
    }

    var aiAvailable: Bool { DJPlanner.canUseAI(language: language.resolved) }
    var availabilityMessage: String { DJPlanner.availabilityMessage(language: language.resolved) }
    var canSpeakNow: Bool {
        isEnabled && NowPlaying.shared.isPlaying
            && !(NowPlaying.shared.videoId ?? "").isEmpty
            && PlayerController.shared.currentVideoId == NowPlaying.shared.videoId
            && PlayerController.shared.playState.value == .playing
    }

    func playbackWillChange() {
        stop()
        listeningTask?.cancel()
        listeningTask = nil
    }

    func playbackDidStart(trackID: String?) {
        guard let trackID, !trackID.isEmpty else { return }
        startListeningObservation(trackID: trackID)
        guard currentTrackID != trackID else { return }
        currentTrackID = trackID
        guard isEnabled else { return }
        tracksSinceSpeech += 1
        if tracksSinceSpeech >= max(1, frequency) {
            requestSpeech(delayNanoseconds: 1_500_000_000)
        }
    }

    func speakNow() {
        requestSpeech(delayNanoseconds: 0, manual: true)
    }

    func stop() {
        requestID = UUID()
        generationTask?.cancel()
        generationTask = nil
        planningTimeout?.cancel()
        planningTimeout = nil
        speechTimeout?.cancel()
        speechTimeout = nil
        isPreparing = false
        isSpeaking = false
        activeUtterance = nil
        synthesizer.stopSpeaking(at: .immediate)
        PlayerController.shared.setDJDuckFactor(1)
    }

    private func snapshot() -> DJContext? {
        let playing = NowPlaying.shared
        guard let id = playing.videoId, !playing.title.isEmpty else { return nil }
        let current = DJTrackSnapshot(id: id, title: playing.title, artist: playing.displayArtist)
        let upcoming = playing.upcomingSongs(prefixLimit: 3).map {
            DJTrackSnapshot(id: $0.videoId, title: $0.title, artist: $0.artists.map(\.name).joined(separator: ", "))
        }
        let artistKey = current.artist.lowercased()
        let sessionArtist = (artistTrackIDs[artistKey]?.count ?? 0) >= 3 ? current.artist : nil
        return DJContext(current: current, upcoming: upcoming, sessionArtist: sessionArtist)
    }

    private func requestSpeech(delayNanoseconds: UInt64, manual: Bool = false) {
        stop()
        guard canSpeakNow, let context = snapshot() else { return }
        let token = UUID()
        requestID = token
        let resolvedLanguage = language.resolved
        isPreparing = true
        generationTask = Task { [weak self] in
            if delayNanoseconds > 0 {
                do { try await Task.sleep(nanoseconds: delayNanoseconds) } catch { return }
            }
            guard let self, self.isCurrent(token: token, trackID: context.current.id) else { return }
            self.planningTimeout = Task { [weak self] in
                do { try await Task.sleep(nanoseconds: 8_000_000_000) } catch { return }
                guard let self, self.isCurrent(token: token, trackID: context.current.id) else { return }
                self.generationTask?.cancel()
                self.requestID = UUID()
                let fallback = DJPlanner.basicPlan(sequence: self.sequence)
                self.present(fallback, context: context, language: resolvedLanguage, manual: manual)
            }
            let plan = await DJPlanner.makePlan(context: context, language: resolvedLanguage, sequence: self.sequence, previousTemplate: self.previousTemplate)
            guard !Task.isCancelled, self.isCurrent(token: token, trackID: context.current.id) else { return }
            self.planningTimeout?.cancel()
            self.planningTimeout = nil
            // Queue edits during inference must not become a false promise.
            var currentPlan = plan
            if context.upcoming.first?.id != self.snapshot()?.upcoming.first?.id {
                currentPlan = DJScriptPlan(template: plan.template, mentionNext: false, usedAI: plan.usedAI)
            }
            self.present(currentPlan, context: context, language: resolvedLanguage, manual: manual)
        }
    }

    private func isCurrent(token: UUID, trackID: String) -> Bool {
        requestID == token && isEnabled && NowPlaying.shared.isPlaying && NowPlaying.shared.videoId == trackID
    }

    private func present(_ plan: DJScriptPlan, context: DJContext, language: DJLanguage, manual: Bool) {
        let template = plan.template == previousTemplate ? (plan.template + 1) % 12 : plan.template
        let presentation = DJScriptPlan(template: template, mentionNext: plan.mentionNext, usedAI: plan.usedAI)
        let useHumor = humorEnabled && ((sequence + 1) % 3 == 0 || (manual && sequence == 0))
        let joke = useHumor ? sequence / 3 : nil
        let useSessionComment = context.sessionArtist != nil && (manual || sequence % 3 == 1)
        let text = presentation.render(context: context, language: language, humorIndex: joke, includeSessionComment: useSessionComment)
        speak(text, language: language, usedAI: plan.usedAI, template: template)
    }

    private func preferredVoice(language: DJLanguage) -> AVSpeechSynthesisVoice? {
        let prefix = language == .spanish ? "es" : "en"
        let voices = AVSpeechSynthesisVoice.speechVoices().filter { $0.language.hasPrefix(prefix) }
        func score(_ voice: AVSpeechSynthesisVoice) -> Int {
            let quality: Int
            switch voice.quality {
            case .premium: quality = 3
            case .enhanced: quality = 2
            case .default: quality = 1
            @unknown default: quality = 0
            }
            let region: Int
            if language == .spanish {
                region = voice.language == "es-MX" ? 100 : (voice.language == "es-US" ? 80 : 40)
            } else {
                region = voice.language == "en-US" ? 100 : 40
            }
            return region + quality
        }
        return voices.sorted {
            let left = score($0), right = score($1)
            return left == right ? $0.identifier < $1.identifier : left > right
        }.first ?? AVSpeechSynthesisVoice(language: language.voiceLanguage)
    }

    private func speak(_ text: String, language: DJLanguage, usedAI: Bool, template: Int) {
        guard canSpeakNow else { stop(); return }
        guard let voice = preferredVoice(language: language) else { stop(); return }
        let utterance = AVSpeechUtterance(string: text)
        utterance.voice = voice
        utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.96
        utterance.preUtteranceDelay = 0.12
        utterance.postUtteranceDelay = 0.12
        utterance.volume = 1
        activeUtterance = utterance
        isPreparing = false
        isSpeaking = true
        lastSpeech = text
        lastUsedAI = usedAI
        previousTemplate = template
        sequence += 1
        tracksSinceSpeech = 0
        PlayerController.shared.assertAudioSession()
        PlayerController.shared.applyDJAudioMixing(enabled: true)
        PlayerController.shared.setDJDuckFactor(0.24)
        synthesizer.speak(utterance)
        let token = requestID
        // A missing delegate callback must never leave music attenuated.
        speechTimeout = Task { [weak self] in
            do { try await Task.sleep(nanoseconds: 45_000_000_000) } catch { return }
            guard let self, self.requestID == token else { return }
            self.stop()
        }
    }

    private func startListeningObservation(trackID: String) {
        listeningTask?.cancel()
        listeningTask = nil
        guard isEnabled, canSpeakNow, let context = snapshot(), context.current.id == trackID else { return }
        let track = context.current
        listeningTask = Task { [weak self] in
            var previousPosition = PlayerController.shared.currentTime
            while !Task.isCancelled {
                do { try await Task.sleep(nanoseconds: 1_000_000_000) } catch { return }
                guard let self, self.isEnabled, NowPlaying.shared.videoId == trackID,
                      PlayerController.shared.currentVideoId == trackID else { return }
                let position = PlayerController.shared.currentTime
                let advance = position - previousPosition
                previousPosition = position
                // Pauses and seeks do not earn listening time. Missed background
                // timer ticks are conservatively ignored rather than inferred.
                guard NowPlaying.shared.isPlaying, PlayerController.shared.playState.value == .playing,
                      advance > 0, advance <= 2.5 else { continue }
                self.listeningSeconds[trackID, default: 0] += advance
                guard self.listeningSeconds[trackID, default: 0] >= 30,
                      !self.qualifiedTrackIDs.contains(trackID) else { continue }
                self.qualifiedTrackIDs.insert(trackID)
                if !track.artist.isEmpty {
                    self.artistTrackIDs[track.artist.lowercased(), default: []].insert(trackID)
                }
            }
        }
    }

    private func speechEnded(utteranceID: ObjectIdentifier) {
        guard let utterance = activeUtterance, ObjectIdentifier(utterance) == utteranceID else { return }
        activeUtterance = nil
        speechTimeout?.cancel()
        speechTimeout = nil
        isSpeaking = false
        PlayerController.shared.setDJDuckFactor(1)
    }
}

extension PersonalDJ: AVSpeechSynthesizerDelegate {
    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        let utteranceID = ObjectIdentifier(utterance)
        Task { @MainActor [weak self] in self?.speechEnded(utteranceID: utteranceID) }
    }

    nonisolated func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        let utteranceID = ObjectIdentifier(utterance)
        Task { @MainActor [weak self] in self?.speechEnded(utteranceID: utteranceID) }
    }
}
