import Foundation

// Adapted grounding/closed-shortlist principles: SUB/WAVE v1.31.0.
// See NOTICE.md in this directory. No stream URLs or credentials enter a prompt.
enum DJPreferences {
    static let enabledKey = "izuvibe.dj.enabled"
    static let frequencyKey = "izuvibe.dj.frequency"
    static let languageKey = "izuvibe.dj.language"
    static let humorKey = "izuvibe.dj.humor"

    static var isEnabled: Bool { UserDefaults.standard.bool(forKey: enabledKey) }
}

enum DJLanguage: String, CaseIterable, Identifiable {
    case system, spanish = "es", english = "en"
    var id: String { rawValue }

    @MainActor var resolved: DJLanguage {
        guard self == .system else { return self }
        let code = SettingsStore.shared.appLanguage.locale.language.languageCode?.identifier
            ?? Locale.preferredLanguages.first ?? "en"
        return code.hasPrefix("es") ? .spanish : .english
    }

    var localeIdentifier: String { self == .spanish ? "es-EC" : "en-US" }
    var voiceLanguage: String { self == .spanish ? "es-MX" : "en-US" }
}

struct DJTrackSnapshot: Codable, Sendable {
    let id: String
    let title: String
    let artist: String

    init(id: String, title: String, artist: String) {
        self.id = id
        self.title = Self.clean(title, limit: 100)
        self.artist = Self.clean(artist, limit: 80)
    }

    private static func clean(_ value: String, limit: Int) -> String {
        let plain = value.components(separatedBy: .controlCharacters).joined(separator: " ")
        return String(plain.split(whereSeparator: \.isWhitespace).joined(separator: " ").prefix(limit))
    }
}

struct DJContext: Codable, Sendable {
    let current: DJTrackSnapshot
    let upcoming: [DJTrackSnapshot]
    // Present only after three distinct IDs by this credited artist/group have
    // each accumulated 30 seconds of observed playback during this app session.
    let sessionArtist: String?

    init(current: DJTrackSnapshot, upcoming: [DJTrackSnapshot], sessionArtist: String? = nil) {
        self.current = current
        self.upcoming = upcoming
        self.sessionArtist = sessionArtist
    }
}

struct DJScriptPlan: Sendable {
    let template: Int
    let mentionNext: Bool
    let usedAI: Bool

    // The model selects an allowed presentation; Swift inserts the verified
    // identity. This deliberately prevents invented music facts in spoken text.
    func render(context: DJContext, language: DJLanguage, humorIndex: Int? = nil, includeSessionComment: Bool = false) -> String {
        func identity(_ track: DJTrackSnapshot) -> String {
            guard !track.artist.isEmpty else { return track.title }
            return language == .spanish
                ? "\(track.title), de \(track.artist)"
                : "\(track.title), by \(track.artist)"
        }
        let name = identity(context.current)
        let options: [String]
        if language == .spanish {
            options = [
                "Qué bueno tenerte por aquí. Está sonando \(name).",
                "Seguimos juntos en IzuVibe con \(name).",
                "Un saludito por aquí, y seguimos con \(name).",
                "Hagámosle un espacio a \(name). Ya está sonando.",
                "Tú pones la compañía; yo presento la canción: \(name).",
                "Por si querías guardar el nombre: estás escuchando \(name).",
                "No te quito mucho tiempo: suena \(name).",
                "Me quedo contigo un ratito y con \(name).",
                "Seguimos con la música, sin apuro. Ahora suena \(name).",
                "Por aquí seguimos: \(name), en IzuVibe.",
                "Te mando un saludo y le doy paso a \(name).",
                "Te dejo con \(name). Yo vuelvo en unas canciones."
            ]
        } else {
            options = [
                "Good to have you here. You are listening to \(name).",
                "Keeping you company on IzuVibe with \(name).",
                "A quick hello, then back to \(name).",
                "Let's make a little room for \(name). It's playing now.",
                "You bring the company; I'll introduce the song: \(name).",
                "In case you wanted to save the name: this is \(name).",
                "I'll keep it short: you are listening to \(name).",
                "Sticking around with you and \(name).",
                "No rush. Let's stay with the music and \(name).",
                "Still here with you: \(name), on IzuVibe.",
                "Sending a little hello before we get back to \(name).",
                "I'll leave you with \(name), and be back in a few songs."
            ]
        }
        var text = options[options.indices.contains(template) ? template : 0]
        if includeSessionComment, let artist = context.sessionArtist {
            text += language == .spanish
                ? " Ya han sonado varias canciones de \(artist) en esta sesión."
                : " Several different songs by \(artist) have played in this session."
        } else if humorIndex == nil, mentionNext, let next = context.upcoming.first, !next.title.isEmpty {
            text += language == .spanish
                ? " Después, en tu cola: \(identity(next))."
                : " Next in your queue: \(identity(next))."
        }
        if let humorIndex {
            let jokes = language == .spanish ? [
                "Prometo no cantar encima: mi karaoke sigue en pruebas.",
                "Mi solo favorito es cuando me callo y dejo sonar la música.",
                "Mi instrumento es el botón de reproducir: cero clases, mucha práctica.",
                "Si el botón de repetir hablara, ya tendría su propio pódcast.",
                "Yo pongo la voz. El talento ya viene en la canción.",
                "Listo, se acabó mi concierto de palabras. Que siga la música."
            ] : [
                "I promise not to sing over this. My karaoke is still in testing.",
                "My best solo is when I stop talking and let the music play.",
                "My instrument is the play button. No lessons, plenty of practice.",
                "If the repeat button could talk, it would have its own podcast.",
                "I bring the voice. The talent is already in the song.",
                "That's the end of my word concert. Back to the music."
            ]
            text += " " + jokes[humorIndex % jokes.count]
        }
        return text
    }
}
