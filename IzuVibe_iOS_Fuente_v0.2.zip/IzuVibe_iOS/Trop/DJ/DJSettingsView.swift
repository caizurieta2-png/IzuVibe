import SwiftUI

@MainActor
struct DJSettingsView: View {
    @State private var dj = PersonalDJ.shared

    var body: some View {
        @Bindable var dj = dj
        List {
            Section {
                Toggle("Enable personal DJ", isOn: $dj.isEnabled)
            } footer: {
                Text("The DJ speaks over quieter music. Your queue and playback controls stay yours.")
            }
            Section {
                HStack {
                    Text("DJ engine")
                    Spacer()
                    Text(LocalizedStringKey(dj.aiAvailable ? "On-device AI" : "Basic"))
                        .foregroundStyle(.secondary)
                }
                Text(LocalizedStringKey(dj.availabilityMessage))
                    .font(.footnote)
                    .foregroundStyle(.secondary)
                Picker("DJ voice language", selection: $dj.language) {
                    Text("Follow app language").tag(DJLanguage.system)
                    Text("Spanish").tag(DJLanguage.spanish)
                    Text("English").tag(DJLanguage.english)
                }
                HStack {
                    Text("Friendly style")
                    Spacer()
                    Text("Friendly").foregroundStyle(.secondary)
                }
                Toggle("Occasional humor", isOn: $dj.humorEnabled)
                Stepper(value: $dj.frequency, in: 1...6) {
                    Text("Speak every \(dj.frequency) songs")
                }
            } footer: {
                Text("The system voice is used on this phone. Basic mode uses verified titles and artists; AI chooses the presentation without inventing music facts.")
                Text("Short music jokes, occasionally. No comments about your mood or tastes are guessed.")
            }
            Section {
                Button("Speak now", systemImage: "waveform") { dj.speakNow() }
                    .disabled(!dj.canSpeakNow)
                Button("Stop DJ", systemImage: "stop.fill") { dj.stop() }
                    .disabled(!dj.isSpeaking && !dj.isPreparing)
                if dj.isPreparing {
                    ProgressView("Preparing DJ…")
                }
                if dj.isSpeaking {
                    Label("DJ speaking", systemImage: "speaker.wave.2.fill")
                }
            }
            if !dj.lastSpeech.isEmpty {
                Section("Last presentation") {
                    Text(dj.lastSpeech)
                    Text(LocalizedStringKey(dj.lastUsedAI ? "Chosen with on-device AI" : "Basic presentation"))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Section {
                NavigationLink("DJ credits") { DJCreditsView() }
            }
        }
        .navigationTitle("DJ Izu")
        .navigationBarTitleDisplayMode(.inline)
        .miniPlayerTracksScroll()
    }
}

private struct DJCreditsView: View {
    var body: some View {
        List {
            Text("Grounding and closed-candidate principles adapted from SUB/WAVE v1.31.0, by Parminder Klair (MIT).")
            Link("SUB/WAVE source and license", destination: URL(string: "https://github.com/perminder-klair/subwave/tree/v1.31.0")!)
            Text("This version uses Apple Foundation Models when available and the system speech voice. It does not bundle Kokoro or broadcast a shared radio stream.")
        }
        .navigationTitle("DJ credits")
    }
}
