//
//  AboutSettingsView.swift
//  Trop
//
//  Created by 686udjie on 26/08/2026.
//

import SwiftUI

struct AboutSettingsView: View {
    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    Text("IzuVibe")
                        .font(.title2.bold())
                        .foregroundStyle(SettingsStore.shared.accentColor)
                    Text("Tu música. Tu ritmo.")
                        .foregroundStyle(.secondary)
                }
                .padding(.vertical, 8)
            }

            Section {
                if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String {
                    HStack {
                        Text("Versión")
                        Spacer()
                        Text(version)
                            .foregroundStyle(.secondary)
                    }
                }
            }

            Section {
                Text("IzuVibe es una adaptación del proyecto de código abierto Trop, de SwiftyMedia y sus colaboradores.")
                Text("El código base conserva su licencia GNU GPL v3 y los créditos de sus autores.")
                    .foregroundStyle(.secondary)
                Link(destination: URL(string: "https://github.com/SwiftyMedia/Trop")!) {
                    Text("Código fuente original de Trop")
                }
                Link(destination: URL(string: "https://github.com/SwiftyMedia/Trop/blob/v0.0.4/LICENSE.txt")!) {
                    Text("Licencia GNU GPL v3")
                }
                Link(destination: URL(string: "https://discord.gg/QrMwZAfU97")!) {
                    Text("Comunidad de Trop en Discord")
                }
            } header: {
                Text("Código abierto y créditos")
            }
        }
        .navigationTitle("Acerca de IzuVibe")
        .navigationBarTitleDisplayMode(.inline)
        .miniPlayerTracksScroll()
    }
}
