# Upstream

Proyecto original: https://github.com/SwiftyMedia/Trop
Versión: v0.0.4
Commit: e44d95911d14e47ca77fb2ad7f7cafce8f90eca5
Licencia: GNU General Public License v3.0 (LICENSE.txt original).

Modificaciones de IzuVibe: identidad, iconos, colores/defaults de apariencia, créditos visibles, bundle ID y configuración de compilación manual. Los módulos y copyright originales se conservan. No se presenta esta adaptación como creación de SwiftyMedia ni como producto oficial de Google/YouTube.
