# IzuVibe para iOS — adaptación de Trop

Estado: código adaptado y preparación de compilación. **Todavía no compilado ni instalado en el iPhone.** Este ZIP no es un IPA instalable.

## Base y funciones reutilizadas

Base: SwiftyMedia/Trop v0.0.4, commit e44d95911d14e47ca77fb2ad7f7cafce8f90eca5.
https://github.com/SwiftyMedia/Trop/releases/tag/v0.0.4

Se conserva la búsqueda y resolución nativa de YouTube Music mediante SwiftyTube/InnerTube; reproductor MPV, biblioteca, playlists, historial, letras, descargas, ecualizador y controles en segundo plano del proyecto original. No es una integración iTunes ni un iframe de la web. Esas funciones heredadas no se han verificado en tu dispositivo; dependen de servicios externos y pueden cambiar.
La documentación original pide cuenta YouTube Music mediante su web de inicio de sesión dentro de la app; no afirma exigir Premium. No entregues contraseñas en el chat. Los secretos de Last.fm que venían en el código se retiraron: esa integración opcional queda sin configurar. Discord conserva identificadores del proveedor original y no forma parte de las funciones configuradas de esta adaptación.

## Cambios de IzuVibe

- Nombre visible IzuVibe y bundle ID app.izuvibe.ios.
- Celeste #65d9ff, tema oscuro y fondo de reproductor negro por defecto.
- Icono de barras musicales; los iconos alternativos mantienen el símbolo propio.
- Pantalla Acerca de con créditos y licencia originales.
- Esquema compartido Xcode para compilación reproducible.
- Workflow manual que genera IzuVibe.ipa sin firmar. Se archivaron los workflows de publicación automática originales.
- El proyecto, módulo y target internos siguen llamándose Trop para conservar sus rutas de compilación.

## Requisitos reales

El README original dice iOS26+, pero el proyecto de esta versión exige **iOS26.2 o posterior**. Se conserva el requisito real del proyecto; no se redujo sin pruebas.
La compilación necesita macOS/Xcode. Desde Windows se puede ejecutar en un runner de GitHub. No hace falta comprar un Mac.

## Compilar desde Windows usando GitHub

1. Publica este código en un repositorio propio, conservando LICENSE.txt y los créditos. Este paso NO se ha realizado por el asistente.
2. Para evitar costos, el workflow de este paquete solo corre en repositorios públicos con runner estándar. En un repositorio privado se omitirá el job. Revisa siempre las condiciones vigentes de GitHub: https://docs.github.com/en/actions/concepts/billing-and-usage .
3. Abre Actions → IzuVibe - compilar iOS → Run workflow.
4. La primera compilación recompila FFmpeg y puede tardar bastante. No se disparó ninguna compilación ni se consumieron minutos durante la preparación local.
5. Al terminar, descarga el artefacto IzuVibe-iOS-sin-firmar y extrae IzuVibe.ipa.
6. Ese IPA requiere firma/instalación con AltStore Classic, SideStore u otro método compatible. No se instala desde Safari con un toque. Una cuenta gratuita de Apple requiere renovaciones periódicas; AltStore documenta siete días.
   https://faq.altstore.io/altstore-classic/how-to-install-altstore-windows
   https://faq.altstore.io/altstore-classic/your-altstore

## Prueba previa del proyecto original

Para comprobar la reproducción upstream antes de compilar cambios, el autor ofrece un IPA sin firmar en la release v0.0.4 enlazada arriba. Su feed puede estar desincronizado; usa la release estable directa. Ese IPA es Trop original, no la adaptación IzuVibe ni una compilación que haya hecho el asistente.

## Licencia y atribución

Trop, SwiftyMedia y colaboradores: GNU GPLv3, texto original en LICENSE.txt sin cambios.
Las modificaciones de esta adaptación se distribuyen bajo la misma licencia. Si redistribuyes binarios, debes cumplir sus condiciones y proporcionar el código fuente correspondiente. Esto no cambia los permisos ni términos del catálogo remoto.
Los avisos y copyright del código heredado permanecen intactos. README.md es el documento original. Los workflows/feed originales se conservan como referencia en upstream/.

## Verificación realizada

Se verificaron estructura del plist y esquema XML, JSON de los iconos, consistencia del target y referencias de assets, ausencia de la dependencia privada Discord Social SDK de main, conservación del archivo GPL y cambios de marca. No se ejecutó Xcode, no se generó IzuVibe.ipa y no se probó reproducción, descarga o acceso a cuentas en el iPhone. La siguiente verificación necesaria es una compilación real de este código en macOS.
