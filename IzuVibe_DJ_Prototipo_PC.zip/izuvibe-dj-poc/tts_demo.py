#!/usr/bin/env python3
"""Render one short Spanish DJ intervention with local Kokoro ONNX on CPU.

Use Python 3.10-3.13 (the portable demo uses 3.12). All supplied paths must
remain inside this demo directory; only the requested WAV is written.

This original wrapper uses the public kokoro-onnx API, rather than copying
SUB/WAVE's persistent worker. API and provenance:
https://github.com/thewh1teagle/kokoro-onnx (MIT library)
https://huggingface.co/hexgrad/Kokoro-82M (Apache-2.0 model)
https://github.com/perminder-klair/subwave/blob/main/controller/scripts/kokoro_worker.py
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys
import time
import wave


DEMO_DIR = Path(__file__).resolve().parent
MAX_TEXT_BYTES = 32_768
MAX_TEXT_CHARS = 4_000
LANGUAGE = "es"


def local_path(value: str, label: str) -> Path:
    """Resolve an explicitly supplied path without following it outside the demo."""
    path = Path(value).resolve()
    if not path.is_relative_to(DEMO_DIR):
        raise ValueError(f"{label} must be inside the izuvibe-dj-poc directory")
    return path


def input_file(value: str, label: str, suffix: str | None = None) -> Path:
    path = local_path(value, label)
    if not path.is_file():
        raise ValueError(f"{label} does not exist or is not a regular file")
    if suffix and path.suffix.lower() != suffix:
        raise ValueError(f"{label} must have the {suffix} extension")
    if path.stat().st_size == 0:
        raise ValueError(f"{label} is empty")
    return path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--text-file", required=True, help="UTF-8 plain text to speak")
    parser.add_argument("--model", required=True, help="Downloaded Kokoro .onnx model")
    parser.add_argument("--voices", required=True, help="Downloaded voices-v1.0.bin")
    parser.add_argument("--output", required=True, help="Destination WAV inside runs/")
    parser.add_argument("--voice", choices=("ef_dora", "em_alex", "em_santa"), default="ef_dora")
    parser.add_argument("--speed", type=float, default=0.98)
    parser.add_argument("--threads", type=int, default=4)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    started = time.perf_counter()
    try:
        if not (3, 10) <= sys.version_info[:2] < (3, 14):
            raise ValueError("kokoro-onnx 0.6.1 requires Python 3.10-3.13; use the portable Python 3.12")
        if not 0.8 <= args.speed <= 1.2 or not 1 <= args.threads <= 8:
            raise ValueError("speed must be 0.8-1.2; threads must be 1-8")

        text_path = input_file(args.text_file, "text file")
        model_path = input_file(args.model, "model", ".onnx")
        voices_path = input_file(args.voices, "voices", ".bin")
        output_path = local_path(args.output, "output")
        runs_dir = DEMO_DIR / "runs"
        if not output_path.is_relative_to(runs_dir):
            raise ValueError("output must be inside the demo's runs directory")
        if output_path.suffix.lower() != ".wav":
            raise ValueError("output must have the .wav extension")
        if output_path.exists() and not output_path.is_file():
            raise ValueError("output is not a regular file")
        if output_path in (text_path, model_path, voices_path):
            raise ValueError("output cannot replace an input file")
        if text_path.stat().st_size > MAX_TEXT_BYTES:
            raise ValueError("text file is too large for this brief demo")

        text = text_path.read_text(encoding="utf-8-sig").strip()
        if not text or "\x00" in text:
            raise ValueError("text must contain nonempty UTF-8 plain text")
        if len(text) > MAX_TEXT_CHARS:
            raise ValueError(f"text must contain at most {MAX_TEXT_CHARS} characters")

        # A deliberate CPU-only proof of concept, with no PyTorch dependency.
        os.environ["ONNX_PROVIDER"] = "CPUExecutionProvider"
        import numpy as np
        import onnxruntime as rt
        from kokoro_onnx import Kokoro

        loading = time.perf_counter()
        options = rt.SessionOptions()
        options.intra_op_num_threads = args.threads
        options.inter_op_num_threads = 1
        session = rt.InferenceSession(str(model_path), sess_options=options, providers=["CPUExecutionProvider"])
        kokoro = Kokoro.from_session(session, str(voices_path))
        loaded = time.perf_counter()
        try:
            samples, sample_rate = kokoro.create(text, voice=args.voice, lang=LANGUAGE,
                                                speed=args.speed, sentence_pause=0.32, clause_pause=0.12)
        finally:
            kokoro.voices.close()
        rendered = time.perf_counter()

        audio = np.asarray(samples, dtype=np.float32)
        if audio.ndim != 1 or audio.size == 0 or not np.isfinite(audio).all():
            raise ValueError("Kokoro returned invalid or empty mono audio")
        sample_rate = int(sample_rate)
        if not 8_000 <= sample_rate <= 192_000:
            raise ValueError("Kokoro returned an invalid sample rate")
        peak = float(np.max(np.abs(audio)))
        if peak <= 1e-8:
            raise ValueError("Kokoro returned silent audio")
        # Older exports can be louder. Reduce excessive peaks before PCM16
        # conversion, preserving relative levels without clipping the waveform.
        gain = min(1.0, 0.98 / peak)
        pcm = np.rint(np.clip(audio * gain, -1.0, 1.0) * 32767).astype("<i2")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with wave.open(str(output_path), "wb") as wav_file:
            wav_file.setnchannels(1)
            wav_file.setsampwidth(2)
            wav_file.setframerate(sample_rate)
            wav_file.writeframes(pcm.tobytes())

        duration = audio.size / sample_rate
        print(json.dumps({
            "ok": True,
            "output": str(output_path),
            "voice": args.voice,
            "speed": args.speed,
            "threads": args.threads,
            "language": LANGUAGE,
            "provider": "CPUExecutionProvider",
            "sample_rate": sample_rate,
            "duration_s": round(duration, 3),
            "model_load_s": round(loaded - loading, 3),
            "synthesis_s": round(rendered - loaded, 3),
            "real_time_factor": round((rendered - loaded) / duration, 3),
            "peak_before_gain": round(peak, 5),
            "gain": round(gain, 5),
            "total_s": round(time.perf_counter() - started, 3),
        }, ensure_ascii=False), flush=True)
        return 0
    except Exception as error:
        print(json.dumps({"ok": False, "error": str(error)}, ensure_ascii=False), file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
