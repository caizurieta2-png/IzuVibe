# IzuVibe: prueba breve de DJ personal

Esta prueba ya ejecutó Qwen3-1.7B Q4_K_M mediante llama.cpp en CPU para elegir
tres IDs y un estilo de presentación. La aplicación valida esa decisión y
construye una locución breve con plantillas amigables y el título/artista real
del primer tema. **La locución no es prosa libre generada por Qwen.** Kokoro
ONNX, voz española `ef_dora`, convirtió el texto en un WAV local.

No inicia Navidrome, Icecast, una API de pago ni reproducción de las canciones.
El catálogo de prueba contiene metadatos, sin grabaciones. El ZIP pequeño
incluye código, manifiesto y resultados; no incluye modelos, binarios ni el
entorno Python. `prepare_assets.py` descarga recursos públicos con SHA-256.

## Procedencia fijada

Fuente: [SUB/WAVE v1.31.0](https://github.com/perminder-klair/subwave/releases/tag/v1.31.0),
commit `5cfabe5b7fe6f0c9b08d562509f0adedd6213e85`, licencia MIT.
Se leyeron `AGENTS.md` (remite a `CLAUDE.md`), `CLAUDE.md`,
`controller/CLAUDE.md` y la sección pertinente de `docs/internals/music.md`
antes de adaptar. El árbol upstream permanece sin cambios de código.

Adaptaciones de código y de instrucciones, sin importar sus dependencias:

- [`shortlist-pick.ts`, líneas 141–177](https://github.com/perminder-klair/subwave/blob/5cfabe5b7fe6f0c9b08d562509f0adedd6213e85/controller/src/broadcast/dj-agent/shortlist-pick.ts#L141):
  contrato de ID exacto de una lista cerrada y `shortlistCandidateForPick`.
  `normalizeDjCandidates` adapta su proyección por campos permitidos y su
  `Object.fromEntries(...filter(...))`. Esta prueba exige tres IDs y comprueba
  pertenencia exacta sin reparación por similitud, sin selección de respaldo.
- [`shortlist-pick.ts`, líneas 211–256](https://github.com/perminder-klair/subwave/blob/5cfabe5b7fe6f0c9b08d562509f0adedd6213e85/controller/src/broadcast/dj-agent/shortlist-pick.ts#L211):
  `shortlistPickPrompt`: candidatos serializados como JSON, historial como
  contexto y atributos ausentes como desconocidos. `buildDjPrompt` lo adapta
  al español y una sesión personal. El constructor `buildDjPrompt` conserva el
  experimento de prosa; el flujo ejecutado usa `buildDjDecisionPrompt` de
  `decision.mjs`, con tres selecciones y un estilo cerrado.
- [`schemas.ts`, líneas 24–31 y 62–65](https://github.com/perminder-klair/subwave/blob/5cfabe5b7fe6f0c9b08d562509f0adedd6213e85/controller/src/broadcast/dj-agent/schemas.ts#L24):
  nunca inventar/componer IDs; identidad verificada en el controlador.
  Esta prueba mantiene la identidad y la resolución de audio en la aplicación.
- [`grounding.ts`, líneas 16–23](https://github.com/perminder-klair/subwave/blob/5cfabe5b7fe6f0c9b08d562509f0adedd6213e85/controller/src/llm/internal/prompts/grounding.ts#L16):
  el estilo y el contexto no autorizan inventar ubicación u otros hechos.
  La adaptación omite ubicación, clima y biografías por completo.
- [`docs/internals/music.md`, líneas 306–324](https://github.com/perminder-klair/subwave/blob/5cfabe5b7fe6f0c9b08d562509f0adedd6213e85/docs/internals/music.md#L306):
  proyección compacta y contexto limitado a datos conocidos, como fundamento
  de la separación entre catálogo original y vista que recibe el modelo.

Los límites de palabras, la selección de tres, la validación estricta sin
dependencias y el fixture de metadatos son propios de esta prueba. No se copia
el sistema de emisión, TTS, descubrimiento ni catálogo de SUB/WAVE.

## Flujo ejecutado y contrato de integración

`run_demo.mjs` llama a `buildDjDecisionPrompt({request, candidates, history})`.
Elimina previamente de los candidatos el ID reciente del fixture y envía a
Qwen un esquema JSON cerrado. El modelo devuelve únicamente:

```json
{"trackIds":["ID exacto 1","ID exacto 2","ID exacto 3"],"style":"welcome"}
```

`style` admite `welcome`, `transition` o `concise`. `validateDjDecision`
comprueba las claves, el estilo y tres IDs distintos del catálogo disponible.
`renderDjDecision` inserta título/artista verificados en una de tres plantillas
de la aplicación. Después usa `validateDjPlan` para comprobar el texto final.
El resultado se guarda en `runs/plan.json` y la locución en `runs/intro.txt`.
`tts_demo.py` usa Kokoro ONNX en CPU, produce WAV mono PCM16 y comunica tiempos.

El arnés usa Qwen3-1.7B Q4_K_M, llama.cpp `b12340` y Kokoro `0.6.1` con
`kokoro-v1.0.int8.onnx` del release `model-files-v1.1` y `voices-v1.0.bin`.
Las URLs, tamaños y hashes están en `assets-manifest.json`. El modelo Qwen de
esta ejecución pesa 1.282.439.264 bytes; no se utilizó el modelo pequeño de
0,6B explorado anteriormente. Ninguno de esos pesos se redistribuye en el ZIP.

## Helpers conservados

`buildDjPrompt({request, candidates, history = []})` devuelve texto.
`request` admite 1–280 caracteres. `candidates` admite de 3 a 100 objetos con
`id`, `title`, `artist` y, opcionalmente, `album`, `genre`, `moods`, `energy`.
Estos atributos opcionales deben proceder de la aplicación, no de una
suposición del modelo. Se omiten URLs, credenciales y campos internos.
`history` es una lista cronológica de IDs o de objetos con `id`; sólo se pasan
los últimos doce IDs. El historial no amplía el catálogo elegible.

Ese helper anterior pide al modelo JSON con esta forma; **no es el contrato
del flujo ejecutado por `run_demo.mjs`**:

```json
{"trackIds":["ID exacto 1","ID exacto 2","ID exacto 3"],"intro":"Entre veinte y treinta y cinco palabras en español."}
```

`validateDjPlan(obj, candidates)` recibe el JSON ya parseado, devuelve una copia
`{trackIds, intro}` válida o lanza `Error`/`TypeError`. Rechaza IDs desconocidos,
duplicados, cantidades incorrectas, claves adicionales y presentaciones fuera
de longitud, con URLs o etiquetas. No corrige IDs. El arnés debe descartar una
respuesta inválida. El audio se resuelve después a partir de los registros
originales de la aplicación, nunca de una URL inventada por el modelo.

La validación automática comprueba el contrato. El flujo ejecutado limita los
hechos hablados mediante plantillas de la aplicación y metadatos confirmados;
no deduce géneros, ánimo, biografías ni gustos personales. La naturalidad y la
entonación del audio requieren valoración auditiva; las pruebas no la sustituyen.

## Datos demo y comprobación

`fixture-catalog.json` contiene seis títulos/artistas confirmados en páginas
oficiales de artistas o del sello, con fuentes y IDs locales `demo-*`. No
contiene audio, enlaces de reproducción dentro de candidatos, medidas musicales
inventadas ni un catálogo real del usuario. Las URLs de `sources` documentan
la procedencia y no se incluyen en el prompt. La fuente de Antología es una
interpretación en vivo; el fixture identifica la canción, no un archivo concreto.

Pruebas aisladas, sólo con Node y sin paquetes:

```powershell
node --test contract.test.mjs decision.test.mjs
```

La comprobación actual pasó 13 pruebas: 11 del contrato y 2 de la decisión.
La ejecución real produjo la presentación amigable de Antología, de Shakira,
con Qwen en 7,586 s y un WAV de 10,597 s. El hilo principal registró 54,815 s
de síntesis Kokoro en CPU; ese tiempo no implica síntesis en tiempo real.
`PRUEBAS.md` distingue las métricas registradas de las verificaciones del
paquete. No se repitieron LLM ni TTS para empaquetar.

Esta prueba PC utiliza Kokoro. El port iOS preparado utiliza Apple Foundation
Models cuando está disponible y voz del sistema, con alternativa básica.
No promete la misma voz que el WAV del PC. Este ZIP no contiene la app móvil,
y la comprobación PC no acredita compilación, mezcla de audio ni funcionamiento
en iPhone o Android.

## Dependencias externas

SUB/WAVE y kokoro-onnx usan licencia MIT; los pesos Kokoro y Qwen se publican
con Apache 2.0; llama.cpp usa MIT. Los modelos y binarios se descargan desde
sus fuentes indicadas por el manifiesto y conservan sus propias licencias.
Fuentes: https://github.com/thewh1teagle/kokoro-onnx,
https://huggingface.co/hexgrad/Kokoro-82M,
https://huggingface.co/ggml-org/Qwen3-1.7B-GGUF,
https://github.com/ggml-org/llama.cpp.

## Licencia original conservada

MIT License

Copyright (c) 2026 Parminder Klair

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
