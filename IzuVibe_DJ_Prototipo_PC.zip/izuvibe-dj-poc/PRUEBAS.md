# Comprobaciones del prototipo PC

Fecha de comprobación del paquete: 12 de noviembre de 2026.

## Ejecución real registrada

- Cerebro: Qwen3-1.7B Q4_K_M, llama.cpp `b12340`, CPU, sin API de pago.
- Salida real: IDs `demo-shakira-antologia`, `demo-soda-musica` y
  `demo-julieta-limon`; estilo `welcome`.
- Tiempo de Qwen: **7,586 s**, leído de `runs/plan.json`.
- La presentación fue construida por `renderDjDecision` con una plantilla y
  metadatos verificados; no es prosa libre del modelo.
- Voz: Kokoro ONNX `ef_dora`, español. El hilo principal registró **54,815 s**
  de síntesis CPU para el audio nuevo. No se repitió TTS para empaquetar.

## Verificado durante el empaquetado

La orden `node --test contract.test.mjs decision.test.mjs` pasó **13/13**:
11 pruebas del contrato y 2 de decisión/renderizado amigable. Comprueban IDs
exactos, orden y pertenencia; duplicados y cantidades; claves inesperadas;
límites de texto; rechazo de enlaces/etiquetas; proyección de metadatos;
historial acotado; fixture; y renderizado de los estilos para sus títulos.

Se reabrió el WAV con la biblioteca estándar `wave`, sin sintetizar:

| Propiedad | Resultado |
|---|---|
| Archivo incluido | `runs/IzuVibe_DJ_Amigable.wav` |
| Tamaño | 508.680 bytes |
| Canales | 1, mono |
| Frecuencia | 24.000 Hz |
| Muestra | PCM16, 2 bytes |
| Fotogramas | 254.318 |
| Duración | 10,596583 s, redondeada 10,597 s |
| SHA-256 | `7152fa272a5793c0fd82fdaea8d4a31d1bae52b0df2aeea795d2f8c0414756cf` |

El audio de `outputs/IzuVibe_DJ_Amigable.wav` coincide byte por byte con la
salida nueva de la ejecución. `runs/intro.txt` coincide con `plan.json`, y el
plan contiene tres IDs distintos. El ZIP se comprueba abriéndolo, validando CRC
y leyendo sus entradas; se excluyen pesos, ejecutables y entornos Python.

## Límites de esta verificación

El WAV es técnicamente legible. Esta comprobación de empaquetado no evaluó
auditivamente naturalidad, entonación ni preferencia por la voz; tampoco volvió
a ejecutar Qwen o Kokoro. Las 13 pruebas no demuestran gustos del usuario ni
una selección musical basada en audio real.

No se reproduce música comercial en este prototipo. La voz PC de Kokoro no es
la voz del sistema del port iOS. Compilación Xcode, instalación y mezcla de voz
con música en iPhone, Bluetooth y segundo plano se verifican por separado.
