import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { performance } from 'node:perf_hooks';
import { buildDjDecisionPrompt, renderDjDecision, DJ_STYLES } from './decision.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const runDir = path.join(root, 'runs');
fs.mkdirSync(runDir, { recursive: true });
const fixture = JSON.parse(fs.readFileSync(path.join(root, 'fixture-catalog.json'), 'utf8'));
const request = process.argv.slice(2).join(' ').trim()
  || 'Saluda como DJ Izu y anuncia sólo el título y artista del primer tema elegido. Escribe dos frases cortas, unas veinticinco palabras y un cierre acogedor.';
const history = ['demo-juanes-camisa'];
// Apply recency before choosing: the small model cannot reselect a recent item.
const eligible = fixture.candidates.filter(c => !history.includes(c.id));
const prompt = buildDjDecisionPrompt({ request, candidates: eligible, history });
const schema = {
  type: 'object',
  properties: {
    trackIds: { type: 'array', items: { type: 'string', enum: eligible.map(c => c.id) }, minItems: 3, maxItems: 3 },
    style: { type: 'string', enum: DJ_STYLES },
  },
  required: ['trackIds', 'style'], additionalProperties: false,
};
const promptFile = path.join(runDir, 'prompt.txt');
const schemaFile = path.join(runDir, 'schema.json');
fs.writeFileSync(promptFile, prompt + '\n/no_think\n', 'utf8');
fs.writeFileSync(schemaFile, JSON.stringify(schema), 'utf8');
const binary = path.join(root, 'tools', 'llama', 'llama-completion.exe');
const model = path.join(root, 'assets', 'models', 'Qwen3-1.7B-Q4_K_M.gguf');
const start = performance.now();
const result = spawnSync(binary, [
  '-m', model, '-f', promptFile, '--json-schema-file', schemaFile,
  '--conversation', '--single-turn', '--jinja', '--reasoning', 'off',
  '--no-display-prompt', '--simple-io', '--color', 'off',
  '-c', '4096', '-n', '256', '-t', '4', '--temp', '0.55', '--seed', '42',
], { cwd: root, encoding: 'utf8', windowsHide: true, timeout: 120000, maxBuffer: 8 * 1024 * 1024 });
const elapsed = (performance.now() - start) / 1000;
fs.writeFileSync(path.join(runDir, 'llama-output.txt'), result.stdout ?? '', 'utf8');
fs.writeFileSync(path.join(runDir, 'llama-log.txt'), result.stderr ?? '', 'utf8');
if (result.error || result.status !== 0) {
  throw result.error ?? new Error(`LLM exited ${result.status}; inspect runs/llama-log.txt`);
}
const raw = result.stdout ?? '';
const first = raw.indexOf('{');
const last = raw.lastIndexOf('}');
if (first < 0 || last < first) throw new Error('LLM did not return a JSON object');
const plan = renderDjDecision(JSON.parse(raw.slice(first, last + 1)), eligible);
const resolved = plan.trackIds.map(id => fixture.candidates.find(c => c.id === id));
const report = {
  demo: true, mode: 'personal-dj-proof-of-concept',
  source: 'SUB/WAVE v1.31.0 prompt policy adaptation; see NOTICE.md',
  brain: 'Qwen3-1.7B Q4_K_M via llama.cpp CPU, local, no paid API',
  speech_origin: 'Application-rendered script using validated model selection and style; not free-form model prose.',
  request, ...plan, tracks: resolved,
  generation_s: Number(elapsed.toFixed(3)),
  music: 'Metadata-only fixture; does not contain or play these recordings.',
};
fs.writeFileSync(path.join(runDir, 'plan.json'), JSON.stringify(report, null, 2) + '\n', 'utf8');
fs.writeFileSync(path.join(runDir, 'intro.txt'), plan.intro + '\n', 'utf8');
console.log(JSON.stringify(report, null, 2));
