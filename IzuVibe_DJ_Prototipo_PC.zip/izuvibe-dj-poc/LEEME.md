# IzuVibe: prototipo de DJ personal para PC

Primero **extrae el ZIP completo** en una carpeta. Puedes escuchar la muestra
incluida en `runs/IzuVibe_DJ_Amigable.wav` sin instalar nada.

El prototipo ejecutado hace lo siguiente:

1. Qwen3-1.7B local elige tres IDs del catálogo de ejemplo y un estilo.
2. La aplicación valida los IDs y escribe una presentación amigable con los
   títulos/artistas confirmados. No es texto libre de Qwen.
3. Kokoro ONNX, voz española `ef_dora`, convierte esa presentación en audio.

No incluye ni reproduce canciones. El fixture contiene seis registros de
metadatos con fuentes; la selección no representa gustos reales del usuario.
No necesita Docker, Ollama, Navidrome, Icecast ni una API de pago.

## Requisitos para volver a generar

- Windows x64, Python 3.12 y Node.js. La prueba registrada usó Python 3.12.16
  y Node.js 24.18.0. Kokoro 0.6.1 admite Python 3.10–3.13; Python 3.14 no sirve
  para esta dependencia.
- Internet para instalar paquetes y descargar recursos la primera vez.
- Espacio para aproximadamente 1,45 GB de recursos del manifiesto, además de
  Python y sus paquetes. Estos archivos grandes **no están dentro del ZIP**.
- CPU y tiempo: en la prueba, generar 10,597 segundos de voz tardó 54,815
  segundos de síntesis. La velocidad cambia según el equipo y la carga.

Python: https://www.python.org/downloads/windows/
Node.js: https://nodejs.org/

## Preparación y ejecución

Abre PowerShell dentro de la carpeta extraída que contiene este LEEME.
Estos comandos preparan un entorno local; no es necesario activarlo ni cambiar
la política de ejecución de PowerShell.

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-tts.txt
.\.venv\Scripts\python.exe prepare_assets.py
node --test contract.test.mjs decision.test.mjs
node run_demo.mjs "Saluda con calidez para una nueva sesión de música y elige tres canciones de este catálogo."
.\.venv\Scripts\python.exe tts_demo.py --text-file runs/intro.txt --model assets/models/kokoro-v1.0.int8.onnx --voices assets/models/voices-v1.0.bin --output runs/IzuVibe_DJ_Amigable.wav --voice ef_dora --speed 0.98 --threads 4
```

Si `py -3.12` no encuentra Python, instala o selecciona primero un intérprete
3.12. El ejecutable portátil del equipo de desarrollo no se redistribuye aquí.
`prepare_assets.py` descarga llama.cpp, Qwen y Kokoro en esta misma carpeta,
verifica tamaño/SHA-256 y extrae llama.cpp dentro de `tools/llama`.

`run_demo.mjs` escribe el plan y texto de `runs/`. La última orden escribe el
WAV y muestra un JSON con duración, voz, velocidad, hilos y tiempos. El texto
que recibe TTS debe estar dentro de esta carpeta; la salida debe estar en
`runs/`. Puedes reproducir el WAV con tu reproductor habitual.

Las versiones y hashes de modelos/runtime están fijados en el manifiesto.
Las dependencias transitivas de Python se resuelven al instalar; no se promete
una reproducción idéntica byte por byte ni los mismos tiempos.

## Archivos y resultados

- `decision.mjs` y `run_demo.mjs`: decisión cerrada y ejecución real de Qwen.
- `contract.mjs`: validación de datos/IDs y de la presentación final.
- `prompt.mjs`: helper de un experimento anterior de prosa; no lo usa el arnés.
- `prepare_assets.py`, `assets-manifest.json`: recursos públicos y hashes.
- `tts_demo.py`, `requirements-tts.txt`: voz Kokoro en CPU, sin PyTorch.
- `fixture-catalog.json`: metadatos de ejemplo y procedencia.
- `runs/plan.json`, `runs/intro.txt`, `runs/IzuVibe_DJ_Amigable.wav`: resultado
  real incluido, que las órdenes anteriores reemplazarán con una nueva ejecución.
- `PRUEBAS.md`: alcance de lo verificado. `NOTICE.md`: atribución y licencia.

El ZIP excluye los modelos, binarios, descargas, `.venv` y el audio anterior.

## PC y móvil son implementaciones diferentes

Esta muestra PC usa **Kokoro `ef_dora`**. El port iOS preparado usa
**FoundationModels de Apple y voz del sistema**, con alternativa básica cuando
Apple Intelligence no esté disponible. La voz móvil aún requiere selección y
escucha en el dispositivo; este WAV no demuestra cómo sonará en iPhone.

El ZIP es el prototipo PC. No contiene IPA/APK y no acredita compilación Xcode,
audio en segundo plano, mezcla con música ni funcionamiento móvil.
