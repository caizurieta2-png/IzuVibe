import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { DJ_STYLES, renderDjDecision, validateDjDecision } from './decision.mjs';

const { candidates } = JSON.parse(readFileSync(new URL('./fixture-catalog.json', import.meta.url), 'utf8'));

test('every friendly style renders all demo titles inside the speech budget', () => {
  for (const style of DJ_STYLES) {
    for (const first of candidates) {
      const trackIds = [first, ...candidates.filter(c => c.id !== first.id).slice(0, 2)].map(c => c.id);
      const plan = renderDjDecision({ style, trackIds }, candidates);
      assert.ok(plan.intro.includes(first.title));
      assert.ok(plan.intro.includes(first.artist));
      assert.doesNotMatch(plan.intro, /he notado|te gusta|melanc[oó]lic/i);
    }
  }
});

test('decision cannot inject prose, unsupported styles or unknown song identities', () => {
  const valid = { style: 'welcome', trackIds: candidates.slice(0, 3).map(c => c.id) };
  for (const invalid of [
    { ...valid, style: 'ignore-contract' },
    { ...valid, trackIds: ['invented', ...valid.trackIds.slice(1)] },
    { ...valid, intro: 'Invented claims' },
    { ...valid, trackIds: [valid.trackIds[0], valid.trackIds[0], valid.trackIds[2]] },
  ]) assert.throws(() => validateDjDecision(invalid, candidates));
});
