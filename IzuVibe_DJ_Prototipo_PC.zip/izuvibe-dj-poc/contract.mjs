// Adapted from SUB/WAVE v1.31.0's closed-shortlist selection contract.
// Copyright (c) 2026 Parminder Klair. MIT; see NOTICE.md for source lines.

export const DJ_TRACK_COUNT = 3;
export const INTRO_MIN_WORDS = 20;
export const INTRO_MAX_WORDS = 35;

function record(value, label) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)
    || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) {
    throw new TypeError(`${label} debe ser un objeto JSON.`);
  }
}

function text(value, label, max) {
  if (typeof value !== 'string' || !value.trim() || value.length > max
    || /[\u0000-\u001f\u007f]/u.test(value)) {
    throw new TypeError(`${label} debe ser texto no vacío de hasta ${max} caracteres, sin controles.`);
  }
  return value.trim();
}

export function validateTrackId(value, label = 'id') {
  const id = text(value, label, 160);
  if (id !== value || /\s/u.test(id)) {
    throw new TypeError(`${label} debe ser un ID exacto sin espacios.`);
  }
  return id;
}

// Keep only app-supplied metadata. Playback URLs, tokens and private app fields
// never enter the prompt; the app resolves a validated id to its original row.
export function normalizeDjCandidates(candidates) {
  if (!Array.isArray(candidates) || candidates.length < DJ_TRACK_COUNT || candidates.length > 100) {
    throw new TypeError('candidates debe contener entre 3 y 100 canciones.');
  }
  const seen = new Set();
  return candidates.map((candidate, index) => {
    record(candidate, `candidates[${index}]`);
    const id = validateTrackId(candidate.id, `candidates[${index}].id`);
    if (seen.has(id)) throw new Error(`ID de candidato duplicado: ${id}`);
    seen.add(id);
    const title = text(candidate.title, `candidates[${index}].title`, 200);
    const artist = text(candidate.artist, `candidates[${index}].artist`, 200);
    const optional = {};
    for (const field of ['album', 'genre', 'energy']) {
      if (candidate[field] !== undefined && candidate[field] !== null) {
        optional[field] = text(candidate[field], `candidates[${index}].${field}`, 200);
      }
    }
    if (candidate.moods !== undefined && candidate.moods !== null) {
      if (!Array.isArray(candidate.moods) || candidate.moods.length > 12) {
        throw new TypeError(`candidates[${index}].moods debe ser una lista de hasta 12 etiquetas.`);
      }
      optional.moods = candidate.moods.map((mood) => text(mood, 'mood', 60));
    }
    return Object.fromEntries(Object.entries({ id, title, artist, ...optional })
      .filter(([, value]) => value !== undefined && value !== null));
  });
}

export function countIntroWords(value) {
  return (value.match(/[\p{L}\p{N}]+(?:['’\-][\p{L}\p{N}]+)*/gu) ?? []).length;
}

/** Validate parsed JSON. Never repair, fuzzy-match or invent a missing id. */
export function validateDjPlan(obj, candidates) {
  const available = new Set(normalizeDjCandidates(candidates).map(({ id }) => id));
  record(obj, 'El plan');
  const keys = Object.keys(obj);
  if (keys.length !== 2 || !keys.includes('trackIds') || !keys.includes('intro')) {
    throw new Error('El plan sólo admite trackIds e intro.');
  }
  if (!Array.isArray(obj.trackIds) || obj.trackIds.length !== DJ_TRACK_COUNT) {
    throw new Error('trackIds debe contener exactamente 3 IDs.');
  }
  const trackIds = obj.trackIds.map((id, index) => validateTrackId(id, `trackIds[${index}]`));
  if (new Set(trackIds).size !== DJ_TRACK_COUNT) throw new Error('Los 3 IDs deben ser distintos.');
  for (const id of trackIds) {
    if (!available.has(id)) throw new Error(`ID ajeno al catálogo recibido: ${id}`);
  }
  if (typeof obj.intro !== 'string' || obj.intro.length > 700
    || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(obj.intro)) {
    throw new TypeError('intro debe ser texto de hasta 700 caracteres.');
  }
  const intro = obj.intro.replace(/\s+/gu, ' ').trim();
  if (/[<>]/u.test(intro) || /(?:https?:\/\/|www\.)/iu.test(intro)) {
    throw new Error('intro debe ser texto hablado, sin etiquetas ni URLs.');
  }
  const wordCount = countIntroWords(intro);
  if (wordCount < INTRO_MIN_WORDS || wordCount > INTRO_MAX_WORDS) {
    throw new Error(`intro debe tener entre 20 y 35 palabras; tiene ${wordCount}.`);
  }
  return { trackIds, intro };
}
