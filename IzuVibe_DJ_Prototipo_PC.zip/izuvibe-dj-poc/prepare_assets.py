"""Download pinned public demo resources, verify their hashes, unpack llama.cpp."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent

def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def download(entry):
    target = (ROOT / entry['file']).resolve()
    if not target.is_relative_to(ROOT):
        raise ValueError('Resource path leaves demo directory')
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_file() and target.stat().st_size == entry['bytes'] and sha(target) == entry['sha256']:
        return f"Verified cached: {entry['file']}"
    partial = target.with_suffix(target.suffix + '.part')
    request = urllib.request.Request(entry['url'], headers={'User-Agent': 'IzuVibe-DJ-local-demo/0.1'})
    with urllib.request.urlopen(request, timeout=60) as response, partial.open('wb') as stream:
        while chunk := response.read(1024 * 1024):
            stream.write(chunk)
    if partial.stat().st_size != entry['bytes'] or sha(partial) != entry['sha256']:
        raise ValueError(f"Resource checksum mismatch: {entry['file']}")
    partial.replace(target)
    return f"Downloaded and verified: {entry['file']} ({entry['bytes']} bytes)"

def main():
    entries = json.loads((ROOT / 'assets-manifest.json').read_text(encoding='utf-8'))
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for result in pool.map(download, entries):
            print(result, flush=True)
    destination = ROOT / 'tools' / 'llama'
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(ROOT / 'downloads' / 'llama-cpu.zip') as bundle:
        for item in bundle.infolist():
            path = (destination / item.filename).resolve()
            if not path.is_relative_to(destination.resolve()):
                raise ValueError('Invalid archive entry')
        if bundle.testzip():
            raise ValueError('Corrupt runtime ZIP')
        bundle.extractall(destination)
    print('llama.cpp runtime unpacked inside demo tools directory.', flush=True)

if __name__ == '__main__':
    main()
