/* IzuVibe modifications, 2026. Licensed under GPL-3.0. */
package com.metrolist.music.playback

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.datastore.preferences.core.Preferences
import androidx.media3.common.Player
import com.metrolist.music.constants.AppLanguageKey
import com.metrolist.music.constants.IzuDjEnabledKey
import com.metrolist.music.constants.IzuDjHumorKey
import com.metrolist.music.constants.IzuDjLanguageKey
import com.metrolist.music.constants.IzuDjNameKey
import com.metrolist.music.constants.SYSTEM_DEFAULT
import com.metrolist.music.extensions.currentMetadata
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.Locale

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
internal class IzuDjController(
    private val context: Context,
    private val scope: CoroutineScope,
    preferences: Flow<Preferences>,
    private val currentPlayer: () -> Player,
    private val canSpeak: () -> Boolean,
    private val setDucking: (Boolean) -> Unit,
) {
    private data class Settings(
        val enabled: Boolean = false,
        val name: String = "",
        val humor: Boolean = true,
        val language: String = "system",
        val appLanguage: String = SYSTEM_DEFAULT,
    )

    private val handler = Handler(Looper.getMainLooper())
    private val policy = DjAnnouncementPolicy()
    private var settings = Settings()
    private var engine: TextToSpeech? = null
    private var ready = false
    private var released = false
    private var announcementJob: Job? = null
    private var activeUtterance: String? = null
    private var sequence = 0L
    private val settingsJob = scope.launch {
        preferences.map {
            Settings(
                enabled = it[IzuDjEnabledKey] ?: true,
                name = it[IzuDjNameKey].orEmpty(),
                humor = it[IzuDjHumorKey] ?: true,
                language = it[IzuDjLanguageKey] ?: "system",
                appLanguage = it[AppLanguageKey] ?: SYSTEM_DEFAULT,
            )
        }.distinctUntilChanged().collect {
            settings = it
            cancel()
            if (!it.enabled) policy.reset()
        }
    }

    fun onPlayerEvents(events: Player.Events) {
        if (released) return
        val player = currentPlayer()
        if (events.containsAny(Player.EVENT_MEDIA_ITEM_TRANSITION, Player.EVENT_POSITION_DISCONTINUITY)) cancel()
        if (!settings.enabled || !player.isPlaying || !canSpeak()) {
            cancel()
            return
        }
        val track = player.currentMetadata ?: return
        if (track.isEpisode || track.title.isBlank() || !policy.onTrackPlaying(track.id)) return
        val spokenSettings = settings
        val utterance = "izuvibe-dj-${++sequence}"
        announcementJob = scope.launch {
            try {
                delay(1400)
                if (!stillPlaying(track.id)) return@launch
                initializeEngine()
                repeat(40) {
                    if (!ready && !released) delay(100)
                }
                val tts = engine ?: return@launch
                if (!ready || !stillPlaying(track.id)) return@launch
                val language = djLanguage(
                    spokenSettings.language,
                    spokenSettings.appLanguage,
                    context.resources.configuration.locales[0].language,
                )
                val locale = if (language == "es") Locale.forLanguageTag("es-MX") else Locale.US
                // Use an installed local voice so the DJ never calls a cloud voice service.
                val voice = tts.voices?.filter {
                    it.locale.language == language && !it.isNetworkConnectionRequired &&
                        !it.features.orEmpty().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
                }?.sortedWith(
                    compareBy<android.speech.tts.Voice> {
                        when {
                            it.locale == locale -> 0
                            language == "es" && it.locale.country == "MX" -> 0
                            language == "es" && it.locale.country == "US" -> 1
                            else -> 2
                        }
                    }.thenByDescending { it.quality }.thenBy { it.latency },
                )?.firstOrNull() ?: return@launch
                if (tts.setVoice(voice) != TextToSpeech.SUCCESS) return@launch
                tts.setSpeechRate(1.02f)
                val text = policy.announcement(
                    track.title, track.artists.joinToString(", ") { it.name },
                    spokenSettings.name, language == "es", spokenSettings.humor,
                )
                activeUtterance = utterance
                if (tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utterance) == TextToSpeech.ERROR) return@launch
                // A faulty engine may omit its completion callback; never leave the music ducked.
                delay(20_000)
            } catch (_: RuntimeException) {
                // Missing or malfunctioning speech engines must not interrupt music playback.
            } finally {
                if (activeUtterance == utterance) {
                    activeUtterance = null
                    runCatching { engine?.stop() }
                    setDucking(false)
                }
            }
        }
    }

    private fun stillPlaying(trackId: String): Boolean =
        !released && settings.enabled && currentPlayer().isPlaying && canSpeak() &&
            currentPlayer().currentMediaItem?.mediaId == trackId

    private fun initializeEngine() {
        if (engine != null || released) return
        engine = TextToSpeech(context.applicationContext) { status ->
            handler.post {
                if (!released) ready = status == TextToSpeech.SUCCESS
            }
        }.apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build(),
            )
            setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    handler.post {
                        if (activeUtterance != utteranceId || released) return@post
                        if (currentPlayer().isPlaying && canSpeak()) {
                            setDucking(true)
                        } else cancel()
                    }
                }

                override fun onDone(utteranceId: String?) = finish(utteranceId)

                @Deprecated("Required by the Android TTS interface")
                override fun onError(utteranceId: String?) = finish(utteranceId)

                override fun onError(utteranceId: String?, errorCode: Int) = finish(utteranceId)
            })
        }
    }

    private fun finish(utteranceId: String?) {
        handler.post {
            if (activeUtterance == utteranceId && !released) cancel()
        }
    }

    fun cancel() {
        announcementJob?.cancel()
        announcementJob = null
        activeUtterance = null
        runCatching { engine?.stop() }
        setDucking(false)
    }

    fun release() {
        released = true
        settingsJob.cancel()
        cancel()
        runCatching { engine?.shutdown() }
        engine = null
        handler.removeCallbacksAndMessages(null)
    }
}
