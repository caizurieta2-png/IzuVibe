/* IzuVibe modifications, 2026. Licensed under GPL-3.0. */
package com.metrolist.music.ui.screens.settings

import android.app.Activity
import android.app.LocaleManager
import android.os.Build
import android.os.LocaleList
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.metrolist.music.LocalPlayerAwareWindowInsets
import com.metrolist.music.R
import com.metrolist.music.constants.AppLanguageKey
import com.metrolist.music.constants.IzuDjEnabledKey
import com.metrolist.music.constants.IzuDjHumorKey
import com.metrolist.music.constants.IzuDjLanguageKey
import com.metrolist.music.constants.IzuDjNameKey
import com.metrolist.music.constants.SYSTEM_DEFAULT
import com.metrolist.music.ui.component.EnumDialog
import com.metrolist.music.ui.component.Material3SettingsGroup
import com.metrolist.music.ui.component.Material3SettingsItem
import com.metrolist.music.utils.rememberPreference
import com.metrolist.music.utils.safeDataStoreEdit
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IzuDjSettings(navController: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val spanish = LocalConfiguration.current.locales[0].language == "es"
    val (enabled, onEnabledChange) = rememberPreference(IzuDjEnabledKey, true)
    val (humor, onHumorChange) = rememberPreference(IzuDjHumorKey, true)
    val (name, onNameChange) = rememberPreference(IzuDjNameKey, "")
    val (language, onLanguageChange) = rememberPreference(IzuDjLanguageKey, "system")
    val appLanguage by rememberPreference(AppLanguageKey, SYSTEM_DEFAULT)
    var showVoiceLanguage by remember { mutableStateOf(false) }
    var showAppLanguage by remember { mutableStateOf(false) }

    @Composable
    fun label(english: Int, spanishText: Int) = stringResource(if (spanish) spanishText else english)

    @Composable
    fun languageLabel(value: String) = when (value) {
        "es" -> "Español"
        "en" -> "English"
        else -> label(R.string.izuvibe_follow_system, R.string.izuvibe_follow_system_es)
    }

    if (showVoiceLanguage) {
        EnumDialog(
            onDismiss = { showVoiceLanguage = false },
            onSelect = { onLanguageChange(it); showVoiceLanguage = false },
            title = label(R.string.izuvibe_voice_language, R.string.izuvibe_voice_language_es),
            current = language,
            values = listOf("system", "es", "en"),
            valueText = { languageLabel(it) },
        )
    }
    if (showAppLanguage) {
        EnumDialog(
            onDismiss = { showAppLanguage = false },
            onSelect = { selected ->
                showAppLanguage = false
                scope.launch {
                    if (context.safeDataStoreEdit { it[AppLanguageKey] = selected }) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            context.getSystemService(LocaleManager::class.java).applicationLocales =
                                LocaleList.forLanguageTags(if (selected == SYSTEM_DEFAULT) "" else selected)
                        } else {
                            (context as? Activity)?.recreate()
                        }
                    }
                }
            },
            title = stringResource(R.string.app_language),
            current = appLanguage,
            values = listOf(SYSTEM_DEFAULT, "es", "en"),
            valueText = { languageLabel(it) },
        )
    }

    Column(
        Modifier.windowInsetsPadding(LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
            .verticalScroll(rememberScrollState()),
    ) {
        TopAppBar(
            title = { Text("DJ IzuVibe") },
            navigationIcon = {
                IconButton(onClick = { navController.navigateUp() }) {
                    androidx.compose.material3.Icon(painterResource(R.drawable.arrow_back), stringResource(R.string.back_button_desc))
                }
            },
        )
        Column(Modifier.padding(16.dp)) {
            Material3SettingsGroup(
                title = "IzuVibe",
                items = listOf(
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.music_note),
                        title = { Text(label(R.string.izuvibe_dj_enabled, R.string.izuvibe_dj_enabled_es)) },
                        description = { Text(label(R.string.izuvibe_dj_description, R.string.izuvibe_dj_description_es)) },
                        trailingContent = { Switch(enabled, onEnabledChange) },
                        onClick = { onEnabledChange(!enabled) },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.language),
                        title = { Text(label(R.string.izuvibe_voice_language, R.string.izuvibe_voice_language_es)) },
                        description = { Text(languageLabel(language)) },
                        onClick = { showVoiceLanguage = true },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.language),
                        title = { Text(stringResource(R.string.app_language)) },
                        description = { Text(languageLabel(appLanguage)) },
                        onClick = { showAppLanguage = true },
                    ),
                    Material3SettingsItem(
                        icon = painterResource(R.drawable.music_note),
                        title = { Text(label(R.string.izuvibe_humor, R.string.izuvibe_humor_es)) },
                        description = { Text(label(R.string.izuvibe_humor_description, R.string.izuvibe_humor_description_es)) },
                        trailingContent = { Switch(humor, onHumorChange) },
                        onClick = { onHumorChange(!humor) },
                    ),
                ),
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { onNameChange(it.take(40)) },
                label = { Text(label(R.string.izuvibe_name, R.string.izuvibe_name_es)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            Text(label(R.string.izuvibe_voice_note, R.string.izuvibe_voice_note_es))
        }
    }
}
