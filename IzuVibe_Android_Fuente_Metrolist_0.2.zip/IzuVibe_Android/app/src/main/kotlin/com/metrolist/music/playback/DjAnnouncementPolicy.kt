/* IzuVibe modifications, 2026. Licensed under GPL-3.0. */
package com.metrolist.music.playback

internal class DjAnnouncementPolicy {
    private var lastTrackId: String? = null
    private var playedTracks = 0
    private var announcements = 0

    fun onTrackPlaying(trackId: String): Boolean {
        if (trackId.isBlank() || trackId == lastTrackId) return false
        lastTrackId = trackId
        playedTracks++
        return playedTracks % 3 == 0
    }

    fun reset() {
        lastTrackId = null
        playedTracks = 0
        announcements = 0
    }

    fun announcement(title: String, artists: String, name: String, spanish: Boolean, humor: Boolean): String {
        val safeTitle = cleanSpeechText(title, 160)
        val safeArtists = cleanSpeechText(artists, 100)
        val safeName = cleanSpeechText(name, 40)
        val greeting = if (safeName.isEmpty()) "" else "$safeName, "
        val credit = if (safeArtists.isEmpty()) "" else if (spanish) " de $safeArtists" else " by $safeArtists"
        val identity = "$safeTitle$credit"
        val introductions = if (spanish) {
            listOf(
                "Qué bueno tenerte por aquí. Está sonando $identity.",
                "Seguimos juntos en IzuVibe con $identity.",
                "Un saludito por aquí, y seguimos con $identity.",
                "Hagámosle un espacio a $identity. Ya está sonando.",
                "Tú pones la compañía; yo presento la canción: $identity.",
                "Por si querías guardar el nombre: estás escuchando $identity.",
                "No te quito mucho tiempo: suena $identity.",
                "Me quedo contigo un ratito y con $identity.",
                "Seguimos con la música, sin apuro. Ahora suena $identity.",
                "Por aquí seguimos: $identity, en IzuVibe.",
                "Te mando un saludo y le doy paso a $identity.",
                "Te dejo con $identity. Yo vuelvo en unas canciones.",
            )
        } else {
            listOf(
                "Good to have you here. You are listening to $identity.",
                "Keeping you company on IzuVibe with $identity.",
                "A quick hello, then back to $identity.",
                "Let's make a little room for $identity. It's playing now.",
                "You bring the company; I'll introduce the song: $identity.",
                "In case you wanted to save the name: this is $identity.",
                "I'll keep it short: you are listening to $identity.",
                "Sticking around with you and $identity.",
                "No rush. Let's stay with the music and $identity.",
                "Still here with you: $identity, on IzuVibe.",
                "Sending a little hello before we get back to $identity.",
                "I'll leave you with $identity, and be back in a few songs.",
            )
        }
        announcements++
        val introduction = introductions[(announcements - 1) % introductions.size]
        val text = greeting + if (greeting.isEmpty()) introduction else introduction.replaceFirstChar { it.lowercase() }
        if (!humor || announcements % 3 != 0) return text
        val jokes = if (spanish) {
            listOf(
                "Prometo no cantar encima: mi karaoke sigue en pruebas.",
                "Mi solo favorito es cuando me callo y dejo sonar la música.",
                "Mi instrumento es el botón de reproducir: cero clases, mucha práctica.",
                "Si el botón de repetir hablara, ya tendría su propio pódcast.",
                "Yo pongo la voz. El talento ya viene en la canción.",
                "Listo, se acabó mi concierto de palabras. Que siga la música.",
            )
        } else {
            listOf(
                "I promise not to sing over this. My karaoke is still in testing.",
                "My best solo is when I stop talking and let the music play.",
                "My instrument is the play button. No lessons, plenty of practice.",
                "If the repeat button could talk, it would have its own podcast.",
                "I bring the voice. The talent is already in the song.",
                "That's the end of my word concert. Back to the music.",
            )
        }
        return text + " " + jokes[((announcements / 3) - 1) % jokes.size]
    }
}

internal fun cleanSpeechText(text: String, limit: Int): String =
    text.filterNot { it.isISOControl() }.replace(Regex("\\s+"), " ").trim().take(limit)

internal fun djLanguage(selected: String, appLanguage: String, systemLanguage: String): String {
    val language = if (selected == "es" || selected == "en") selected else {
        if (appLanguage == "SYSTEM_DEFAULT") systemLanguage else appLanguage
    }
    return if (language.substringBefore('-').equals("es", ignoreCase = true)) "es" else "en"
}
