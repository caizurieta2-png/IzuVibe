/* IzuVibe modifications, 2026. Licensed under GPL-3.0. */
package com.metrolist.music.playback

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DjAnnouncementPolicyTest {
    @Test
    fun announcesEveryThirdDifferentPlayingTrackWithoutRepeatingOnPauseOrSeek() {
        val policy = DjAnnouncementPolicy()
        assertFalse(policy.onTrackPlaying("one"))
        assertFalse(policy.onTrackPlaying("one"))
        assertFalse(policy.onTrackPlaying("two"))
        assertTrue(policy.onTrackPlaying("three"))
        assertFalse(policy.onTrackPlaying("three"))
        assertFalse(policy.onTrackPlaying("four"))
        assertFalse(policy.onTrackPlaying("five"))
        assertTrue(policy.onTrackPlaying("six"))
        policy.reset()
        assertFalse(policy.onTrackPlaying("seven"))
    }

    @Test
    fun speaksRealMetadataAndOptionalNameInBothLanguages() {
        val policy = DjAnnouncementPolicy()
        val spanish = policy.announcement("Luna", "Ana", "Carlos", spanish = true, humor = false)
        assertTrue(spanish.contains("Carlos"))
        assertTrue(spanish.contains("Luna de Ana"))
        assertFalse(spanish.contains("karaoke"))
        val english = policy.announcement("Moon", "Anna", "", spanish = false, humor = true)
        assertTrue(english.contains("Moon by Anna"))
        assertFalse(english.contains("karaoke"))
        assertFalse(english.startsWith(","))
    }

    @Test
    fun rotatesTwelveIntroductionsAndSixJokesOnlyEveryThirdAnnouncement() {
        val policy = DjAnnouncementPolicy()
        val introductions = mutableSetOf<String>()
        val jokes = mutableSetOf<String>()
        repeat(18) { index ->
            val text = policy.announcement("Moon", "Anna", "", spanish = false, humor = true)
            val hasJoke = (index + 1) % 3 == 0
            if (index < 12) introductions.add(text.substringBefore("Moon"))
            if (hasJoke) {
                val jokeMarkers = listOf("I promise", "My best solo", "My instrument", "If the repeat", "I bring the voice", "That's the end")
                val marker = jokeMarkers.first { text.contains(it) }
                jokes.add(text.substring(text.indexOf(marker)))
            } else {
                assertFalse(text.contains("karaoke") || text.contains("My best solo") || text.contains("My instrument") || text.contains("own podcast") || text.contains("The talent") || text.contains("word concert"))
            }
        }
        assertEquals(12, introductions.size)
        assertEquals(6, jokes.size)
        val quietPolicy = DjAnnouncementPolicy()
        repeat(3) {
            assertFalse(quietPolicy.announcement("Moon", "Anna", "", spanish = false, humor = false).contains("karaoke"))
        }
    }

    @Test
    fun languageUsesExplicitVoiceThenAppThenSystemAndCapsUntrustedText() {
        assertEquals("en", djLanguage("en", "es", "es"))
        assertEquals("es", djLanguage("system", "es-419", "en"))
        assertEquals("es", djLanguage("system", "SYSTEM_DEFAULT", "es-EC"))
        assertEquals("en", djLanguage("system", "SYSTEM_DEFAULT", "fr"))
        assertEquals("Name", cleanSpeechText(" Name\n\t ", 40))
        assertEquals(40, cleanSpeechText("X".repeat(100), 40).length)
    }
}
