#!/usr/bin/env bash
set -euo pipefail

export METROLIST_APPLICATION_ID=com.izuvibe.music
export METROLIST_APP_NAME=IzuVibe
export GRADLE_OPTS=-Dorg.gradle.daemon=false
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
test -n "$SDK_ROOT"
sdkmanager 'platforms;android-37.0' 'build-tools;36.0.0'
chmod +x gradlew
./gradlew --no-daemon --max-workers=2 --no-parallel \
  -Dorg.gradle.jvmargs='-Xmx4g -Dfile.encoding=UTF-8' \
  -Pkotlin.compiler.execution.strategy=in-process \
  :app:testIzzyDebugUnitTest --tests com.metrolist.music.playback.DjAnnouncementPolicyTest \
  :app:assembleIzzyRelease

mkdir -p dist
TOOLS="$SDK_ROOT/build-tools/36.0.0"
"$TOOLS/zipalign" -P 16 -f 4 app/build/outputs/apk/izzy/release/app-izzy-release-unsigned.apk \
  dist/IzuVibe-Android-aligned-unsigned.apk
"$TOOLS/zipalign" -c -P 16 -v 4 dist/IzuVibe-Android-aligned-unsigned.apk > dist/zipalign-check.txt
"$TOOLS/aapt" dump badging dist/IzuVibe-Android-aligned-unsigned.apk > dist/APK-metadata.txt
python3 - <<'PY'
from pathlib import Path
text = Path('dist/APK-metadata.txt').read_text()
assert "package: name='com.izuvibe.music'" in text, 'Unexpected package id'
assert "application-label:'IzuVibe'" in text, 'Unexpected app label'
assert "sdkVersion:'26'" in text, 'Unexpected minimum Android version'
print('APK identity checked: IzuVibe, com.izuvibe.music, Android API 26+')
PY
cp "$TOOLS/lib/apksigner.jar" dist/
cp LICENSE dist/LICENSE.txt
cp IZUVIBE-NOTICE.txt dist/
cp "$TOOLS/NOTICE.txt" dist/Android-SDK-NOTICE.txt
(
  cd dist
  sha256sum IzuVibe-Android-aligned-unsigned.apk apksigner.jar LICENSE.txt IZUVIBE-NOTICE.txt Android-SDK-NOTICE.txt APK-metadata.txt zipalign-check.txt > SHA256SUMS.txt
)
